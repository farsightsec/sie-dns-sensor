DNS SRV record command line wrapper
-----------------------------------

wrapsrv adds support for connecting to a network service based on DNS SRV
record lookups to commands that do not support the DNS SRV record. wrapsrv
implements the weighted priority client connection algorithm in [RFC
2782](http://tools.ietf.org/html/rfc2782). The specified command line will
be invoked one or more times with %h and %p sequences in the command line
substituted for the hostname and port elements of the selected SRV record.
