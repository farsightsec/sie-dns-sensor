#ifndef _BIND_RPC_XDR_H
#define _BIND_RPC_XDR_H
#include "/usr/include/rpc/xdr.h"
#endif
