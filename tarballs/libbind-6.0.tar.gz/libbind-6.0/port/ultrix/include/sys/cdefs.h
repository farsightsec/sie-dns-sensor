#define __BEGIN_DECLS
#define __END_DECLS
#define __P(x) x
