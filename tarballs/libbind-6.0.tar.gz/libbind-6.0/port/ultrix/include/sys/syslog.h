#ifndef _BIND_SYSLOG_H
#define _BIND_SYSLOG_H
#include "/usr/include/syslog.h"
#endif
